# H1 Musicall, notre plateforme dédiée à la musique en ligne pour tous !

Musicall est un service français d'écoute de musique en streamning sous la forme d'un site web lancé en octobre 2017.

A travers ce site, nous proposons des solutions d'écoute de musique personnalisées à la demande.
Notre plateforme s'adresse au 15-40 ans, et se déploie en 3 offres : l'offre free, premium et famille.
Chacune de ces offres présentent des avantages détaillés sur le site (ex: absence de publicité, musique illimitée hors connexion, etc.).
Notre mission est la suivante : accompagner nos utilisateurs via un service de qualité (recommandations, possibilité de nous contacter 24h/24h...).

Notre objectif : s'ouvrir à l'international en proposant une plateforme traduit en plusieurs langues (anglais, espagnol, italien, chinois et arabe), et développer une application Musicall pour ainsi concurrencer les géants de l'industrie de la musique (Deezer et Spotify).

Et nous alors ?

Notre équipe est composée de  7 jeunes diplômés en marketing digital, passionés par la musique. A la tête de ce projet, Mokhtar, programmateur informatique, assisté par Tatiana et Andréa, designers UX et UI,  et Liana, Francine,  Khaeld et Gloria, responsables de communication et marketing digital.

Nos forces :

Mokhtar Aboulazhr : Proactivité
Tatiana Garcia : Modernité
Andréa Espinosa : Jovialité
Liana Bendali Braham : Créativité
Francine Laurent : Curiosité
Gloria Homegnon : Perfectionniste
Khaled Karafi : Perspicacité 

# Inseecmusicall
